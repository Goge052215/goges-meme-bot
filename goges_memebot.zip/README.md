# Discord Meme Bot

A Discord bot that can send memes, jokes, weather information, and more using slash commands.

## Features

- `/ping` - Check bot latency
- `/meme` - Get a random meme
- `/joke` - Get a random joke
- `/8ball` - Ask the magic 8-ball a question
- `/weather` - Get weather information for a city
- `/help` - List all available commands

## Setup Instructions

### Prerequisites

- Node.js v16.6.0 or higher
- A Discord Bot Token ([Create a bot here](https://discord.com/developers/applications))
- For weather commands: OpenWeatherMap API key ([Sign up here](https://home.openweathermap.org/users/sign_up))

### Installation

1. Clone the repository or download the code
2. Install dependencies:
   ```
   npm install
   ```
3. Run the bot:
   ```
   node replit_memebot.js
   ```

### Setting Up Weather API

To use real weather data with the `/weather` command:

1. Run the setup script:
   ```
   node setup_weather_api.js
   ```
2. Follow the prompts to enter your OpenWeatherMap API key
3. The script will automatically update your environment configuration

### Configuration

On first run, the bot will ask for your Discord token. You can choose to save it for future use.

## Commands

All commands are available as slash commands. Type `/` in Discord to see the available commands.

## Troubleshooting

- **Missing Commands**: If commands aren't showing up in Discord, it may take up to an hour for them to appear after registration.
- **Weather Not Working**: New OpenWeatherMap API keys may take a few hours to activate. Double-check your API key if you're having issues.
- **Port Already in Use**: If you see an EADDRINUSE error, make sure you don't have another instance of the bot running.

## License

MIT 

## Recent Improvements

### YouTube Search Timeout Fixes (2025-05-23)

We've implemented several improvements to make YouTube searches more resilient:

1. **Increased Timeouts**: Search timeouts were increased from 5s to 7s for individual sources and from 10s to 15s overall to allow more time for YouTube searches to complete.

2. **Direct Video ID Matching**: Added a comprehensive mapping of popular songs to their YouTube video IDs for instant matching when exact API searches fail. This provides immediate fallbacks.

3. **Cookie Authentication**: Improved cookie handling with default cookies that help bypass YouTube's "Sign in to confirm you're not a bot" challenges. 

4. **Fallback Stream Creation**: Added a secondary approach for stream creation that attempts a different method when the primary one fails.

5. **Better Format Selection**: Simplified format selection from complex filters to 'bestaudio' to avoid format availability errors.

6. **Expanded Song Matching**: Enhanced song matching to identify titles with artists, using various separators and component matching.

### Usage Tips

- If you encounter YouTube search timeouts, the bot should now automatically fall back to direct video IDs for popular songs.
- If streaming fails, try again - the fallback system now has multiple layers of defense against YouTube API limitations.

## Setup

Follow these instructions to set up and run the bot:

// ... existing content ... 